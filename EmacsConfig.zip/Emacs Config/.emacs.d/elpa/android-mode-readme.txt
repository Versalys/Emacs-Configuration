Provides support for running Android SDK subprocesses like the
emulator, logcat, ddms and ant.  When loaded `dired-mode' and
`find-file' hooks are added to automatically enable `android-mode'
when opening a file or directory in an android project.
