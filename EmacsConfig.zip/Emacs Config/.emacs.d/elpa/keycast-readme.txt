This package provides Keycast mode.  Once enabled, that mode shows
the current command and its key or mouse binding in the mode line,
and updates them whenever another command is invoked.
