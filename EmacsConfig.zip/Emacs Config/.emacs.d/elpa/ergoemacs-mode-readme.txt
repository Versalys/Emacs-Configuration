An efficient keybinding set based on statistics of command
frequency, and supports common Windows shortcuts such as Open,
Close, Copy, Cut, Paste, Undo, Redo.
