An interface for communicating with Jupyter kernels.
