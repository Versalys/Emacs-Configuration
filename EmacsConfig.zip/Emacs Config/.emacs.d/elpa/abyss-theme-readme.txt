A dark theme with contrasting colours for Emacs24 based on the
``Lush`` theme by Andre Richter, using the same colours palette
as the the built-in `dichromacy' theme; intended to be suitable
for red/green colour blind users.
